# SH round 3 listening comparisons

No loudness normalization, clipping, or post-hoc alignment. FLOAT WAV. Timing is model-sample time; computation availability delay is reported separately. Original 0260 horn: DenisChardonnet; rain 0124: Joseph SARDIN; BigSoundBank CC0 https://bigsoundbank.com/licenses.html . Changes: gain-preserving excerpts, additive mixtures, repeated backgrounds/events, official unmodified SH extraction and specified neural-state interventions. Original recording/session independence and genuine binaural capture not established.

The four short stream examples contain exactly the same local mixture at matched event times. The three r1_* folders contain exactly the same original five-second mixture, with only prior state/context changed. See the report for cold-start failures, algorithmic lookahead and CPU-only playback limitations.
