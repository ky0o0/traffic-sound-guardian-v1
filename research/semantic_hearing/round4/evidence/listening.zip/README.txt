FLOAT 44.1kHz stereo WAV; same unchanged level. Original recording stems mixed synthetically; not a blind human listening test.
