# Listening selection

Original sample values and gains preserved as FLOAT WAV; no normalization. Each folder provides input mixture, output extraction, and recorded reference component. Edited mixtures and SH outputs are adaptations.

BigSoundBank recordings by DenisChardonnet and Joseph SARDIN, CC0: https://bigsoundbank.com/licenses.html

IUSB siren01 and traffic_bg01: Jean-Rémy Gloaguen, Mathieu Lagrange, Arnaud Can, Jean-François Petiot, CC BY 4.0; https://zenodo.org/records/1213793 ; https://creativecommons.org/licenses/by/4.0/ . These adaptations are shared under CC BY 4.0. See config.json for exact member paths/hashes/crops and source uncertainty.

Mono bsb_1463 is an explicit dual-mono model-input diagnostic, never real binaural data. No independent human purity annotation or safety validation.
